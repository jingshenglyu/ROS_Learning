
"use strict";

let SpawnTurtle = require('./SpawnTurtle.js')

module.exports = {
  SpawnTurtle: SpawnTurtle,
};
